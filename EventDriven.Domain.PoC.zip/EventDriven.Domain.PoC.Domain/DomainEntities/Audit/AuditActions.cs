﻿namespace EventDriven.Domain.PoC.Domain.DomainEntities.Audit
{
    public enum AuditActions
    {
        I,
        U,
        D
    }
}