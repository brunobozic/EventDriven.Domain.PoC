﻿namespace EventDriven.Domain.PoC.Domain.DomainEntities.UserAggregate.AddressSubAggregate
{
    public class Consts
    {
        public const int DEFAULT_ACTIVETO_VALUE_FOR_ADDRESSES = 100;

        public const int DEFAULT_ACTIVETO_VALUE_FOR_USER_REGISTRATIONS = 50;

        public const int DEFAULT_ACTIVETO_VALUE_FOR_USERADDRESS = 100;
    }
}