﻿using System;
using EventDriven.Domain.PoC.SharedKernel.DomainImplementations.BaseClasses;

namespace EventDriven.Domain.PoC.Domain.DomainEntities.UserAggregate.RoleSubAggregate.RoleDomainEvents
{
    public class RoleRemovedFromUserDomainEvent : DomainEventBase
    {
        public DateTimeOffset? DateRemoved;
        public string RemoverEmail;

        public long RemoverUserId;
        public string RemoverUsername;
        public string Name;
        public string UserName;
        public string UserEmail;
        public long RoleId;
        public long UserId;

        public RoleRemovedFromUserDomainEvent(long userId,string userName, string userEmail, long roleId, string roleName, long removerUserId, string removerUserName, string removerEmail, DateTimeOffset dateRemoved)
        {
            UserId = userId;
            RoleId = roleId;
            RemoverUserId = removerUserId;
            DateRemoved = dateRemoved;
            Name = roleName;
            UserName = userName;
            UserEmail = userEmail;
            RemoverUsername = removerUserName;
            RemoverEmail = removerEmail;
        }
    }
}