﻿using Microsoft.AspNetCore.Authorization;

namespace EventDriven.Domain.PoC.Api.Rest.SecurityPolicies
{
    public class DemoRequirement : IAuthorizationRequirement
    {
    }
}