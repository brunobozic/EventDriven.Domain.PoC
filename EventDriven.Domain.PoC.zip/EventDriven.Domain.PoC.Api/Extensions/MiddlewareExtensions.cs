﻿namespace EventDriven.Domain.PoC.Api.Rest.Extensions
{
    public static class MiddlewareExtensions
    {
        //public static IApplicationBuilder UseAdMiddleware(this IApplicationBuilder builder) =>
        //    builder.UseMiddleware<AdUserMiddleware>();
    }
}