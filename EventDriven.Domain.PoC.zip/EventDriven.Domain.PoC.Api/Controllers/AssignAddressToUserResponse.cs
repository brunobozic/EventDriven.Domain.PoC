﻿namespace EventDriven.Domain.PoC.Api.Rest.Controllers
{
    public class AssignAddressToUserResponse
    {
    }
}