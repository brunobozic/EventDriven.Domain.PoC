﻿namespace EventDriven.Domain.PoC.Api.Rest.Controllers.Contracts
{
    internal interface IUserController
    {
    }
}