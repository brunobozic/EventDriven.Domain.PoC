﻿namespace EventDriven.Domain.PoC.Api.Rest.Controllers.Contracts
{
    public interface IAddressAdministrationService
    {
    }
}