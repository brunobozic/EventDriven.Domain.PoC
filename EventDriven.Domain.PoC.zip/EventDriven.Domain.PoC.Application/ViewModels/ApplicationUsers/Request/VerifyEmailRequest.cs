﻿namespace EventDriven.Domain.PoC.Application.ViewModels.ApplicationUsers.Request
{
    public class VerifyEmailRequest
    {
        public string Token { get; set; }
    }
}