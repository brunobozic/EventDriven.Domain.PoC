﻿namespace EventDriven.Domain.PoC.Application.ViewModels.ApplicationUsers.Request
{
    public class ForgotPasswordRequest
    {
        public string Email { get; set; }
    }
}