﻿namespace EventDriven.Domain.PoC.Application.ViewModels.ApplicationUsers.Request
{
    public class ValidateResetTokenRequest
    {
        public string Token { get; set; }
    }
}