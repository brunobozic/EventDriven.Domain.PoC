﻿namespace EventDriven.Domain.PoC.Application.ViewModels.ApplicationUsers.Request
{
    public class RevokeTokenRequest
    {
        public string Token { get; set; }
    }
}