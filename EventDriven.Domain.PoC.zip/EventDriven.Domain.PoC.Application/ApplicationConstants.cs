﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDriven.Domain.PoC.Application
{
    public class ApplicationConstants
    {
        public const string DEVELOPMENT = "DEVELOPMENT";
        public const string LOCALDEVELOPMENT = "LOCALDEVELOPMENT";
    }
}
