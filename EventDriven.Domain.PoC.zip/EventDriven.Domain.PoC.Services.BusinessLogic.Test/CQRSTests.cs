using Xunit;

namespace EventDriven.Domain.PoC.Services.BusinessLogic.Test
{
    public class CQRSTests
    {
        [Fact]
        public void Test1()
        {
        }
    }
}