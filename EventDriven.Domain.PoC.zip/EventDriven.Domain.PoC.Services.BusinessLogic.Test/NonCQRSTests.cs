using Xunit;

namespace EventDriven.Domain.PoC.Services.BusinessLogic.Test
{
    public class NonCQRSTests
    {
        [Fact]
        public void Test1()
        {
        }
    }
}