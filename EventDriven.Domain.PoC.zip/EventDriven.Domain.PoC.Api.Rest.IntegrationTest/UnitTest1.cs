using Xunit;

namespace EventDriven.Domain.PoC.Api.Rest.Integration.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
        }
    }
}