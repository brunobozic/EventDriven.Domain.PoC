﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace EventDriven.Domain.PoC.Repository.EF.DatabaseContext
{
    public class MyContextContextFactory : IDesignTimeDbContextFactory<ApplicationDbContext>
    {
        public ApplicationDbContext CreateDbContext(string[] args)
        {
            var envName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            if (string.IsNullOrEmpty(envName))
            {
#if DEBUG
                envName = "Development";
#endif
#if !DEBUG
                envName = "Production";
#endif
            }

            Log.Warning("MyContextContextFactory Environment: " + envName);

            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile($"appsettings.{envName}.json", true)
                .Build();

            // Here we create the DbContextOptionsBuilder manually.        
            var builder = new DbContextOptionsBuilder<ApplicationDbContext>();

            // Build connection string. This requires that you have a connectionstring in the appsettings.json
            //var connectionString = configuration.GetConnectionString("MSSql");
            var connectionString = configuration.GetConnectionString("Sqlite");

            Log.Warning("MyContextContextFactory GetConnectionString: " + connectionString);

            builder.UseSqlite(connectionString);
            // builder.UseNpgsql(connectionString);

            // Create our DbContext.
            return new ApplicationDbContext(builder.Options /*, new NoMediator()*/, true);
        }

        public class NoMediator : IMediator
        {
            public Task Publish<TNotification>(TNotification notification,
                CancellationToken cancellationToken = default) where TNotification : INotification
            {
                return Task.CompletedTask;
            }

            public Task Publish(object notification, CancellationToken cancellationToken = default)
            {
                throw new NotImplementedException();
            }

            public Task<TResponse> Send<TResponse>(IRequest<TResponse> request,
                CancellationToken cancellationToken = default)
            {
                return Task.FromResult(default(TResponse));
            }

            public Task<object> Send(object request, CancellationToken cancellationToken = default)
            {
                return Task.FromResult(default(object));
            }

            public Task Send(IRequest request, CancellationToken cancellationToken = default)
            {
                return Task.CompletedTask;
            }
        }
    }
}