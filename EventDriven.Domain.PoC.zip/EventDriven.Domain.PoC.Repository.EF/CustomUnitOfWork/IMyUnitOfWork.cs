﻿using URF.Core.Abstractions;

namespace EventDriven.Domain.PoC.Repository.EF.CustomUnitOfWork
{
    public interface IMyUnitOfWork : IUnitOfWork
    {
    }
}