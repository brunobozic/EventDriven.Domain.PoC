﻿namespace EventDriven.Domain.PoC.SharedKernel.Helpers
{
    public enum RoleEnum
    {
        Admin,
        User
    }
}