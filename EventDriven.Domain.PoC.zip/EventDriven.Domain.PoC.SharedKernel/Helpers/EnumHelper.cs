﻿using System;

namespace EventDriven.Domain.PoC.SharedKernel.Helpers
{
    public static class EnumHelper
    {
        public static T GetEnumValue<T>(this string str) where T : struct, IConvertible
        {
            var enumType = typeof(T);
            if (!enumType.IsEnum) throw new Exception("T must be an Enumeration type.");
            T val;
            return Enum.TryParse(str, true, out val) ? val : default;
        }

        public static T GetEnumValue<T>(int intValue) where T : struct, IConvertible
        {
            var enumType = typeof(T);
            if (!enumType.IsEnum) throw new Exception("T must be an Enumeration type.");

            return (T) Enum.ToObject(enumType, intValue);
        }
    }
}