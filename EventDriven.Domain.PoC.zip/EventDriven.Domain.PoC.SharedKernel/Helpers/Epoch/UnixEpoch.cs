﻿using System;

namespace EventDriven.Domain.PoC.SharedKernel.Helpers.Epoch
{
    public static class UnixEpoch
    {
        public static long ToUnixEpochDate(DateTime date)
        {
            return (long) Math.Round((date.ToUniversalTime() - new DateTimeOffset(1970, 1, 1, 0, 0, 0, TimeSpan.Zero))
                .TotalSeconds);
        }
    }
}