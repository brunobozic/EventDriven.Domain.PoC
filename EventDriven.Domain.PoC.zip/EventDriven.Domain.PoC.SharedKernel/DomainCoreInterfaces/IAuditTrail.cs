﻿namespace EventDriven.Domain.PoC.SharedKernel.DomainCoreInterfaces
{
    public interface IAuditTrail
    {
    }
}