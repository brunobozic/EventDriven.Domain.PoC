﻿namespace EventDriven.Domain.PoC.SharedKernel.DomainCoreInterfaces
{
    public interface IEntityBase
    {
        long Id { get; set; }
    }
}