﻿namespace EventDriven.Domain.PoC.SharedKernel.DomainBaseAbstractions
{
    //public class BaseEntity : IEntityBase, ISoftDeletable, IDeactivatableEntity, ICreationAuditedEntity,
    //    IModificationAuditedEntity, IDeletionAuditedEntity, ITrackable
    //{
    //    private List<IDomainEvent> _domainEvents;

    //    public BaseEntity()
    //    {
    //        Deleted = false;
    //        IsActive = true;
    //    }

    //    [Required] [Column("Name", Order = 1)] public string Name { get; set; }

    //    [Column("Description", Order = 2)] public string Description { get; set; }

    //    [NotMapped] public IList<DomainEventBase> UncommittedDomainEvents { get; } = new List<DomainEventBase>();

    //    /// <summary>
    //    ///     Domain events occurred.
    //    /// </summary>
    //    public IReadOnlyCollection<IDomainEvent> DomainEvents => _domainEvents?.AsReadOnly();

    //    public long CreatedBy { get; set; }

    //    [Required]
    //    [Column("DateCreated", Order = 1005)]
    //    public DateTimeOffset DateCreated { get; set; } = DateTimeOffset.UtcNow;

    //    public long CreatedById { get; set; }

    //    [Required]
    //    [Column("IsActive", Order = 990)]
    //    public bool IsActive { get; set; } = true;

    //    [Required]
    //    [Column("ActiveFrom", Order = 991)]
    //    public DateTimeOffset ActiveFrom { get; set; } = DateTimeOffset.UtcNow;

    //    [Column("ActiveTo", Order = 992)] public DateTimeOffset? ActiveTo { get; set; }

    //    [Key]
    //    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    //    public long Id { get; set; }

    //    [Column("DateModified", Order = 1010)] public DateTimeOffset? DateModified { get; set; }
    //    public long? ModifiedById { get; set; }

    //    public long ModifiedBy { get; set; }

    //    [Column("DateDeleted", Order = 1020)] public DateTimeOffset? DateDeleted { get; set; }
    //    public long? DeletedById { get; set; }

    //    [Required]
    //    [Column("Deleted", Order = 996)]
    //    public bool Deleted { get; set; }

    //    public long DeletedBy { get; set; }

    //    [NotMapped] public TrackingState TrackingState { get; set; }

    //    [NotMapped] public ICollection<string> ModifiedProperties { get; set; }

    //    /// <summary>
    //    ///     Add domain event.
    //    /// </summary>
    //    /// <param name="domainEvent"></param>
    //    protected void AddDomainEvent(IDomainEvent domainEvent)
    //    {
    //        _domainEvents = _domainEvents ?? new List<IDomainEvent>();
    //        _domainEvents.Add(domainEvent);
    //    }

    //    /// <summary>
    //    ///     Clear domain events.
    //    /// </summary>
    //    public void ClearDomainEvents()
    //    {
    //        _domainEvents?.Clear();
    //    }

    //    protected static void CheckRule(IBusinessRule rule)
    //    {
    //        if (rule.IsBroken()) throw new BusinessRuleValidationException(rule);
    //    }
    //}
}