﻿namespace EventDriven.Domain.PoC.SharedKernel.DomainContracts
{
    public interface IAggregateRoot
    {
    }
}