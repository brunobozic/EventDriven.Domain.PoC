﻿using System;
using MediatR;

namespace EventDriven.Domain.PoC.SharedKernel.DomainContracts
{
    public interface IDomainEventNotification<out TEventType> : IDomainEventNotification
    {
        TEventType DomainEvent { get; }
    }

    public interface IDomainEventNotification : INotification
    {
        Guid Id { get; }
    }
}