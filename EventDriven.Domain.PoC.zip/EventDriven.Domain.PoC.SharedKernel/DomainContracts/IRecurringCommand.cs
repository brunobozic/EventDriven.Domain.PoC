﻿namespace EventDriven.Domain.PoC.SharedKernel.DomainContracts
{
    public interface IRecurringCommand
    {
    }
}